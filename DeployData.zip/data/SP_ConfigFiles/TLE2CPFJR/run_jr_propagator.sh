#!/bin/sh

java -cp ./TLE2CPF_oreAPR2021_v1.jar tle2cpf.TLE2CPF $1 $2 $3 $4 ./conf.txt